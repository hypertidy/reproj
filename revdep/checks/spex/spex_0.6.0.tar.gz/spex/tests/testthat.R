library(testthat)
library(spex)

test_check("spex")
