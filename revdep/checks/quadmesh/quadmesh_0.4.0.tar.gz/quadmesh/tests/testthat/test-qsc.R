context("test-qsc")

test_that("qsc projection works", {
  expect_silent(qsc())
})
